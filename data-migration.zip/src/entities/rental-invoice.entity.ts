import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  RelationId,
  Index,
} from 'typeorm';
import { RentalContract } from './rental-contract.entity';

@Entity('rentalInvoice')
@Index(['rentalContract', 'invoiceDueDate'], { unique: true }) // prevent duplicate invoice for same due date
export class RentalInvoice {
  @PrimaryGeneratedColumn()
  rentalInvoiceId: number;

  @ManyToOne(() => RentalContract, (contract) => contract.invoices, {
    nullable: false,
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'rentalContractId' })
  rentalContract: RentalContract;

  @RelationId((invoice: RentalInvoice) => invoice.rentalContract)
  rentalContractId: number;

  @Column({ type: 'timestamp' })
  invoiceDueDate: Date;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  invoiceAmount: number;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  invoiceBalance: number;
}
